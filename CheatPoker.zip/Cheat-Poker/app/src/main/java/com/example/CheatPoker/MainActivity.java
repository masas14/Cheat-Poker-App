package com.example.CheatPoker;

import static android.view.View.VISIBLE;

import static java.util.Calendar.getInstance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView rules, textPopupRules, textRndCode;
    Button btnOnlineGame, btnPrivateGame, btnSignOut, btnBroadcast;
    ProgressBar progressBar;
    LayoutInflater inflaterPopup;
    FirebaseAuth fireBaseUser = FirebaseAuth.getInstance();
    String userUid = fireBaseUser.getCurrentUser().getUid();
    User user = new User(userUid);
    WiFiBroadcastReceiver wifiBroadcastReceiver = new WiFiBroadcastReceiver();
    BroadcastReceiver broadcastReceiver;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);

//        Bundle extras = getIntent().getExtras();
//        String userUid = (String) extras.get("userUid");
//        user = new User(userUid);
//        The key argument here must match that used in the other activity

        broadcastReceiver = new WiFiBroadcastReceiver();
        registerNetworkBroadcastReceiver();

        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);

        rules = (TextView) findViewById(R.id.rules);
        rules.setOnClickListener(this);

        textRndCode = (TextView) findViewById(R.id.textRndCode);

        btnPrivateGame = (Button) findViewById(R.id.btnPrivateGame);
        btnPrivateGame.setOnClickListener(this);

        btnOnlineGame = (Button) findViewById(R.id.btnOnlineGame);
        btnOnlineGame.setOnClickListener(this);

        btnSignOut = (Button) findViewById(R.id.btnSignOut);
        btnSignOut.setOnClickListener(this);

        progressBar = (ProgressBar) findViewById(R.id.progressBar);

        inflaterPopup = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflaterPopup.inflate(R.layout.popup, null);






    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.btnOnlineGame:
                Intent intentOnline = new Intent(MainActivity.this, MainActivity4.class);
                intentOnline.putExtra("userUid",user.getUid());
                startActivity(intentOnline);
                finish();
                break;
            case R.id.btnPrivateGame:
                Intent intentPrivate = new Intent(MainActivity.this, PrivateGameActivity.class);
                intentPrivate.putExtra("userUid",user.getUid());
                startActivity(intentPrivate);
                finish();
                break;
            case R.id.rules:
                String rules = "rules 1, 2, 3";
                textPopupRules.setText(rules);
                textPopupRules.setVisibility(VISIBLE);
                break;

            case R.id.btnSignOut:
                FirebaseAuth.getInstance().signOut();
                Toast.makeText(this, "sign out", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(MainActivity.this, SignInMainActivity.class));
                break;
            default:


        }
    };

    protected void registerNetworkBroadcastReceiver() {
        registerReceiver(broadcastReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
    }

    protected void unregisteredNetwork() {
        try {
            unregisterReceiver (broadcastReceiver);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
                super.onDestroy();
                unregisteredNetwork();
            }
}