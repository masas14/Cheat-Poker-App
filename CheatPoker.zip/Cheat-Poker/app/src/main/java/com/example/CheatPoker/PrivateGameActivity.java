package com.example.CheatPoker;

import static org.junit.Assert.assertEquals;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

//import androidx.test.ext.junit.runners.AndroidJUnit4;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;


import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class PrivateGameActivity extends AppCompatActivity implements View.OnClickListener {

    EditText editTextInsertCode;
    TextView textView;
    Button btnInsertCode, btnGenerateCode, btnJoin;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    CollectionReference gamesReference = db.collection("games");

    Map<String,Object> hashGame = new HashMap<>();
    Map<String,Object> hashGamer = new HashMap<>();

    String lastCode = null;

    FirebaseAuth fireBaseUser = FirebaseAuth.getInstance();
    String userUid = fireBaseUser.getCurrentUser().getUid();
    String userEmail = fireBaseUser.getCurrentUser().getEmail();
    User user = new User(userUid, userEmail);

    Intent p;


    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        p = new Intent(PrivateGameActivity.this, MainActivity4.class);

        btnInsertCode = findViewById(R.id.btnInsertCode);
        btnInsertCode.setOnClickListener(this);

        btnGenerateCode = findViewById(R.id.btnGenerateCode);
        btnGenerateCode.setOnClickListener(this);

        btnJoin = findViewById(R.id.btnJoin);
        btnJoin.setOnClickListener(this);

        editTextInsertCode = findViewById(R.id.editTextInsertCode);
        editTextInsertCode.setOnClickListener(this);

//        for(int i=0; i<13;i++){
//            fake.add(fakeCard);
//        }


    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnGenerateCode:
                editTextInsertCode.setVisibility(View.GONE);
                Bundle extras = getIntent().getExtras();
                String code = addNewGame();
                lastCode = code;
                p.putExtra("generateCode", code);
                p.putExtra("hostUid", fireBaseUser.getCurrentUser().getUid());
                p.putExtra("fullName", extras.getString("fullName"));
                startActivity(p);
                finish();

                break;
            case R.id.btnInsertCode:
                editTextInsertCode.setVisibility(View.VISIBLE);
                btnJoin.setVisibility(View.VISIBLE);

                break;
            case R.id.btnJoin:
                String insertCode = editTextInsertCode.getText().toString().trim();
                gamesReference.document(insertCode).get()
                        .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                            @Override
                            public void onSuccess(DocumentSnapshot documentSnapshot) {
                                DocumentReference gameRef = gamesReference.document(insertCode);
                                gameRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                                    @Override
                                    public void onSuccess(DocumentSnapshot documentSnapshot) {

                                        Bundle extras = getIntent().getExtras();
                                        int numGamers = documentSnapshot.getDouble("numGamers").intValue();
                                        gameRef.update("numGamers", numGamers+1);
                                        gameRef.update("numCards", (int) (26/(numGamers+1)));
                                        CollectionReference gamersRef=gamesReference.document(insertCode).collection("gamers");
                                        gameRef.collection("gamers").document(user.getUid());
                                        hashGamer.put("minusCards",0);
                                        hashGamer.put("username", user.getEmail().replace("@gmail.com", ""));
                                        hashGamer.put("myLastGamer",documentSnapshot.getString("lastGamer"));

                                        user.setMyLastUser(documentSnapshot.getString("lastGamer"));
                                        p.putExtra("myLastGamer",documentSnapshot.getString("lastGamer"));
                                        gameRef.collection("gamers").document(user.getUid()).set(hashGamer);
                                        //gamersRef.document(user.getFullName()).collection("hand").add(null);
                                        gameRef.update("lastGamer", user.getUid());
                            }
                        });


                            }
                        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(PrivateGameActivity.this, "Failed to join to the game",
                                Toast.LENGTH_SHORT).show();
                    }
                });

                p.putExtra("insertCode", insertCode);
                p.putExtra("joined","joined");
                startActivity(p);
                finish();
                break;

        }

    }

    public String addNewGame() {
        Random random = new Random();
        int rnd = random.nextInt(89999) + 10000;
        String code = String.valueOf(rnd);
        HashMap<String,Object> hashCard = new HashMap<>();
        DocumentReference gameRef = gamesReference.document(code);
        hashGame.put("host", user.getUid());
        hashGame.put("lastGamer", user.getUid());
        hashGame.put("status", false);
        hashGame.put("numGamers", 1);
        hashGame.put("numCards", 10);
        hashGame.put("lastHandStrength", 0);
        gameRef.set(hashGame);
        gameRef.collection("lastHand");
        gameRef.collection("gamers").document(user.getUid());
        hashGamer.put("minusCards",0);
        hashGamer.put("username", user.getEmail().replace("@gmail.com", ""));
        gameRef.collection("gamers").document(user.getUid()).set(hashGamer);

        return code;
    }
}




